# react-practice
《React实战：设计模式和最佳实践》源代码

# 介绍

这个repo里的代码是掘金小册《[React实战：设计模式和最佳实践](https://juejin.im/book/5ba42844f265da0a8a6aa5e9)》配套的源代码，欢迎订阅我的[掘金小册](https://juejin.im/book/5ba42844f265da0a8a6aa5e9)，也欢迎在掘金上[关注我](https://juejin.im/user/5b69aceaf265da0faa368ffa)。

如果有什么问题，可以直接在[知乎](https://www.zhihu.com/people/morgancheng/activities)给我私信。

此外，我还有一个知识星球《[进击的React](https://t.zsxq.com/ey7MrBe)》，每个工作日都会发表React最新资讯，欢迎加入。

<img alt="掘金小册封面" src="https://user-gold-cdn.xitu.io/2018/12/4/16779ed4b21a9fa5?w=195&h=273&f=png&s=936421" width=195 />


