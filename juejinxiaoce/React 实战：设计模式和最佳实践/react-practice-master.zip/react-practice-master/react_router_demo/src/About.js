import React from 'react';

const About = () => (
  <div>
    <h1>This is a About Page</h1>
  </div>
);

export default About;
