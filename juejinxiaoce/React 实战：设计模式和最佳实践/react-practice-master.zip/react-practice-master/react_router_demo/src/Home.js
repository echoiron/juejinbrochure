import React from 'react';

const Home = () => (
  <div>
    <h1>Welcome to Home Page</h1>
  </div>
);

export default Home;
