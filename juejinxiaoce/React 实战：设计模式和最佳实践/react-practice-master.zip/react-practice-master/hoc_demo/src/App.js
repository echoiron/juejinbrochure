import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';

import HocDemo from './HocDemo';

class App extends Component {
  render() {
    return (
      <HocDemo />
    );
  }
}

export default App;
