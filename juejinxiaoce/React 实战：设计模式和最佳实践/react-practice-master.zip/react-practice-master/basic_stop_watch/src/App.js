import React, { Component } from 'react';
import './App.css';

import StopWatch from './StopWatch';

class App extends Component {
  render() {
    return (
      <div className="App">
        <StopWatch />
      </div>
    );
  }
}

export default App;
