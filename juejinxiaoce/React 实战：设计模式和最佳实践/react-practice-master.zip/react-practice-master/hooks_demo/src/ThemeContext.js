import React from 'react';

const ThemeContext = React.createContext('foo');

export default ThemeContext;

